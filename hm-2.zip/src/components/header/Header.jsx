import React from 'react';
import Mybutton from '../mybutton/Mybutton';
import "./Header.css"

const Header = (props) => {
    return (
        <div className='header-container'>
            <h2>Favorite Movies</h2>
           <Mybutton>Add Movies</Mybutton>
        </div>
    );
};

export default Header;