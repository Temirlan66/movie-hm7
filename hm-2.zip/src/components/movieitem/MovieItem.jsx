import React from 'react';
import Mybutton from '../mybutton/Mybutton';
import "./MovieItem.css"
const MovieItem = ({data}) => {
    return (
        <li className='movie-element'>
              <div className='movie-element__image'>
                <img src={data.img} alt=""  />
                </div>
            <div className='movie_element__info'>
        <h2>{data.title}</h2>
        <p>{data.rating}/5 starts</p>
        <Mybutton color='red'>Delete</Mybutton>
            <Mybutton color='blue'>Edit</Mybutton>
            </div>

        </li>
      
    );
};

export default MovieItem;