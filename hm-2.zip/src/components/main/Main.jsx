import React from "react";
import { movies } from "../movies";
import  "./Main.css"
import MovieItem from "../movieitem/MovieItem";


const Main = () => {
  return (
    <ul className="movie-list">
        {movies.map((movies,index)=>{
            return <MovieItem data={movies} key={index}/>
        })}
    </ul>
  );
};

export default Main;
